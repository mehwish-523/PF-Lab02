#include<stdio.h>
int main()
{
float time,distance,average_speed;
printf("Enter time in hour:");
scanf("%f",&time);
printf("Enter distance in km:");
scanf("%f",&distance);
average_speed=distance/time;
printf("Average speed is:%.2fkm/hr",average_speed);
return 0;
}