#include<stdio.h>
int main()
{
int pennies,nickles,dimes,quarter,remaning;
pennies=368;
quarter=pennies/25;
remaning=pennies%25;
quarter=pennies/10;
remaning=pennies%10;
quarter=pennies/5;
remaning=pennies%5;
remaning=pennies;
printf("Total pennies=%d\n",pennies);
printf("quarter=%d\n",quarter);
printf("dimes=%d\n",dimes);
printf("nickles=%d\n",nickles);
printf("pennies=%d\n",pennies);
return 0;
}