#include<stdio.h>
int main()
{
int mark1,mark2,mark3,total;
float average;
printf("Enter marks of subject1:");
scanf("%d",&mark1);
printf("Enter marks of subject2:");
scanf("%d",&mark2);
printf("Enter marks of subject3:");
scanf("%d",&mark3);
total=mark1+mark2+mark3;
average=(float)total/3;
printf("Total=%d\n",total);
printf("Average=%.2f\n",average);
return 0;
}
