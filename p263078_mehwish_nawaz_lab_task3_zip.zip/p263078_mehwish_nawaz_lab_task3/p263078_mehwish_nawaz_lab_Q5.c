#include<stdio.h>
#include<math.h>
int main()
{
float a,b,c,x1,x2,discriminant;
printf("Enter value of a:");
scanf("%f",&a);
printf("Enter value of b:");
scanf("%f",&b);
printf("Enter value of c:");
scanf("%f",&c);
discriminant=b*b-4*a*c;
x1=(-b+sqrt(discriminant))/(2*a);
x2=(-b-sqrt(discriminant))/(2*a);
printf("Root 1=%.2f\n",x1);
printf("Root 2=%.2f\n",x2);
return 0;
}




