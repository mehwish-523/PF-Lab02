#include<stdio.h>
int main()
{
float value,diffrence;
int convert;
printf("Enter float Value:");
scanf("%f",&value);
convert=(int)value;
diffrence=value-convert;
printf("Original value=%.2f\n",value);
printf("Diffrence=%.2f\n",diffrence);
return 0;
}
