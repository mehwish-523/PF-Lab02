#include<stdio.h>
int main()
{
int Salary,Tax_rate,Tax,Net_Income;
printf("Enter Your Salary:");
scanf("%d",&Salary);
printf("Enter Your Tax Rate(%%):");
scanf("%d",&Tax_rate);
Tax=Salary*10/100;
Net_Income=Salary_Tax;
printf("Tax Amount is:%d\n",Tax);
printf("Net Income is:%d\n",Net_Income);
return 0;
}  

