#include<stdio.h>
int main()
{
int a,b;
a=7;
b=2;
printf("value of a=%d",a);
printf("value of b=%d",b);
float result1=a/b;
float result2=(float)a/b;
float result3=(float)(a/b);
printf("a/b=%.2f\n",result1);
printf("(float)a/b=%.2f\n",result2);
printf("(float)(a/b)=%.2f\n",result3);
return 0;
}








