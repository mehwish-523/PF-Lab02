#include<stdio.h>
int main()
{
int i,j;
char symbol;
printf("Enter Symbol:");
scanf(" %c",&symbol);
for(i=1;i<=5;i++)
{
for(j=1;j<=i;j++)
{
printf("%c",symbol);
}
printf("\n");
}

 for(i=4;i>=1;i--)
{
for(j=1;j<=i;j++)
{
printf("%c",symbol);
}
printf("\n");
}

return 0;
}
