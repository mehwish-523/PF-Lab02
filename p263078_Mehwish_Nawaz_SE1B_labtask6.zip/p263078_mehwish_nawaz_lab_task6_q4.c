#include<stdio.h>
int main()
{
int total_found=0;
int current_num=2;
int i,factor_sum;
while(total_found<4)
{
   factor_sum=0;
  for(i=1;i<current_num;i++)
{
   if(current_num%i==0)
{
   factor_sum=factor_sum+i;
}
}
  if(factor_sum==current_num)
{
  printf("%d is a Perfect number\n",current_num);
  for(i=1;i<current_num;i++)
{
  if(current_num%i==0)
{
  if(i==1)
{
  printf("%d",i);
}
  else
{
  printf("+%d",i);
}
}
}
  printf("=%d\n",current_num);
  total_found++;
}
  current_num++;
}
return 0;
}

