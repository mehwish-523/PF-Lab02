#include<stdio.h>
int main()
{
int n,x;
double sum=0.0;
int k,i;
printf("Enter value for n:");
scanf("%d",&n);
printf("Enter value for x:");
scanf("%d",&x);
for(k=0;k<=n;k++)
{
double power_val=1.0;
double fact_val=1.0;
for(i=1;i<=k;i++)
{
 power_val=power_val*x;
}
for(i=1;i<=k;i++)
{
 fact_val=fact_val*i;
}
sum=sum+(power_val/fact_val);
}
printf("s=%.1f\n",sum);
return 0;
}


