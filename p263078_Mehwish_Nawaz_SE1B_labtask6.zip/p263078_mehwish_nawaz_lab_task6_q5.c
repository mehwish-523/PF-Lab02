#include<stdio.h>
int main()
{
int n,i,j,k;
char symbol;
printf("Enter number of rows:");
scanf("%d",&n);
printf("Enter symbol:");
scanf(" %c",&symbol);
for(i=1;i<=n;i++)
{
for(k=1;k<=n-i;k++)
{
printf(" ");
}
for(j=1;j<=(2*i-1);j++)
{
printf("%c",symbol);
}
printf("\n");
}
return 0;
}
